
<div class="primary_container">
<div id="container">
	<h1>User Listing</h1>
	<a class="btn btn-primary btn-md" style="float:right;margin: 15px 12px;" href="<?php echo base_url('user/add');?>">Add User</a>
	<div id="body">
		<table id="userListTable" class="table responsive nowrap">
			<thead>
				<tr>
					<th>
						#
					</th>
					<th>
						Full Name
					</th>
					<th>
						User Name
					</th>
					<th>
						Email
					</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($users as $key => $userInfo):?>
				<tr>
					<td><?php echo $userInfo['id'] ?></td>
					<td><?php echo $userInfo['fullname'] ?></td>
					<td><?php echo $userInfo['username'] ?></td>
					<td><?php echo $userInfo['email'] ?></td>
				</tr>
				<?php endforeach;?>
			</tbody>
		</table>
	</div>
</div>