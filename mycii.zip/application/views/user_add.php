
<div class="primary_container">
<div id="container">
	<h1>Add User</h1>
	<a class="btn btn-primary btn-md" style="float:right;margin: 15px 12px;" href="<?php echo base_url('');?>">User List</a>
	

	<div id="body">
		<div class="col-md-12">
			<form id="uform" class="password-strength">
				<div class="form-group">
					<label for="userfullname">Full Name</label>
					<input type="text" class="form-control" id="userfullname" name="userfullname" placeholder="User Full Name">			
				</div>
				<div class="form-group">
					<label for="username">User Name</label>
					<input type="text" class="form-control" id="username"  name="username"  placeholder="User Name">			
				</div>
				<div class="form-group">
					<label for="userpass">Password</label>
					<div class="input-group">
						<input type="password" class="password-strength__input form-control" id="userpass" name="userpass" aria-describedby="passwordHelp" placeholder="Enter password">
						<div class="input-group-append">
						<button class="password-strength__visibility btn btn-outline-secondary" type="button">
							<span class="password-strength__visibility-icon" data-visible="hidden"><i class="fas fa-eye-slash"></i></span>
							<span class="password-strength__visibility-icon js-hidden" data-visible="visible"><i class="fas fa-eye"></i></span>
						</button>
						</div>
					</div>
					<small class="password-strength__error text-danger js-hidden">This symbol is not allowed!</small>
				</div>
				<div class="password-strength__bar-block progress mb-4">
				<div class="password-strength__bar progress-bar bg-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
				</div>
				<div class="form-group clsMailDiv">
					<label for="useremail">Email address</label>
					<input type="email" class="form-control" id="useremail" name="useremail"  aria-describedby="emailHelp"  placeholder="Enter email">			
					<p class="realmail error">Please enter a real email</p>
				</div>
				<input type="hidden" name="add" value="adduser"/>
				<div class="g-recaptcha" data-sitekey="6LdvDQscAAAAAOzzgDnXQHkZGbS_V4v8LMMpIOJ7"></div>
				<button style="margin:10px 0;" type="submit" id="addUserBt" class="password-strength__submit btn btn-primary">Submit</button>
			</form>
		</div>
		
	</div>
</div>


<script src="<?=base_url('assets/js/passwordStrength.js');?>"></script>