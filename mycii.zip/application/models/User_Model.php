<?php
	class User_Model extends CI_Model{

		public $fullname;
        public $username;
        public $userpass;
        public $email;

		public function __construct(){
            parent::__construct();
         }

        public function get_users()
        {
			$query = $this->db->get('users');
            $ret = $query->result_array();
            return $ret;    
        }

		public function insert_user($insertData)
        {
			    $this->fullname    	= $insertData['userfullname']; // please read the below note
                $this->username  	= $insertData['username'];
                $this->userpass     = sha1($insertData['userpass']);
                $this->email     	= $insertData['useremail'];
                return ($this->db->insert('users', $this))  ?   $this->db->insert_id()  :   false;
        }

        
        public function read($id = ''){
           if(empty($id))
           {
            $query = $this->db->query("select * from users");
           }
           else {
            $query = $this->db->query("select * from users where id=".$id);
           }
          
            return $query->result_array();
        }
        public function insert($data){
            $this->fullname    = $data['userfullname']; // please read the below note
            $this->username  = $data['username'];
            $this->userpass = sha1($data['userpass']);
            $this->email = $data['useremail'];
            if($this->db->insert('users',$this))
            {    
                return 'Data is inserted successfully';
            }
            else
            {
                return "Error has occured";
            }
        }
        public function update($id,$data){

            $this->fullname    = $data['userfullname']; // please read the below note
            $this->username  = $data['username'];
            $this->userpass  = sha1($data['userpass']);
            $this->email = $data['useremail'];
            $result = $this->db->update('users',$this,array('id' => $id));
            if($result)
            {
                return "Data is updated successfully";
            }
            else
            {
                return "Error has occurred";
            }
        }
        public function delete($id){

            $result = $this->db->query("delete from `users` where id = $id");
            if($result)
            {
                return "Data is deleted successfully";
            }
            else
            {
                return "Error has occurred";
            }
        }
	}