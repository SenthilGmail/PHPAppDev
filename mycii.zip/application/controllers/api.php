<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Api extends REST_Controller
{
       public function __construct() {
               parent::__construct();
               $this->load->model('user_model');
       }    
       public function user_get(){
            $id = $this->uri->segment(3);
            if(empty($id))
            {
                $r = $this->user_model->read();
            }
            else {
                $r = $this->user_model->read($id);
            }           
            $this->response($r, REST_Controller::HTTP_OK); 
       }
       
       public function user_put(){
           $id = $this->uri->segment(4);
           $data = array(
                'userfullname' => $this->input->put('userfullname'),
                'username' => $this->input->put('username'),
                'userpass' => $this->input->put('userpass'),
                'useremail' => $this->input->put('useremail')
           );
            $r = $this->user_model->update($id,$data);
               $this->response($r); 
       }
       public function user_post(){
           $data = array(
                'userfullname' => $this->input->post('userfullname'),
                'username' => $this->input->post('username'),
                'userpass' => $this->input->post('userpass'),
                'useremail' => $this->input->post('useremail')
           );
           $r = $this->user_model->insert($data);           
           $this->response($r); 
       }
       public function user_delete(){
           $id = $this->uri->segment(4);
           $r = $this->user_model->delete($id);
           $this->response($r); 
       }
    
}