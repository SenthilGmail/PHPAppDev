$(document).ready(function () {
  $('#userListTable').DataTable( {
    responsive: true
  } );

  $("#useremail").on("blur",function(){
      if(!$(this).hasClass("error") && $(this).val()!=""){
        
       let actionUrl = base_url+"user/kickBoxCheck";
          $.ajax({
            type : 'POST',
            url : actionUrl,
            data : { postmail: $(this).val() },
            success: function (data) {
                var res="";
                if(data!="")
                {
                  res = JSON.parse(data);
                  if(res.result == 'deliverable' && res.reason == 'accepted_email')
                  {
                    $(".clsMailDiv").removeClass("noRealMail");
                    $("#addUserBt").removeAttr("disabled");
                  }
                  else {
                    $(".clsMailDiv").addClass("noRealMail");
                    $("#addUserBt").attr("disabled","disabled");
                  }
                }else {
                  $(".clsMailDiv").addClass("noRealMail");
                  $("#addUserBt").attr("disabled","disabled");
                }               
            
            }
        });
      }
  });
    
    $('#uform').validate({
      rules: {
        userfullname: {
          required: true
        },
        useremail: {
          required: true,
          email: true
        },
        username: {
          required: true
        },
        userpass: {
          required: true,
          minlength: 8
        }
      },
      messages: {
        userfullname: 'Please enter Full Name.',
        useremail: {
          required: 'Please enter Email Address.',
          email: 'Please enter a valid Email Address.',
        },
        username: {
          required: 'Please enter User Name.',
        },
        userpass: {
          required: 'Please enter Password.',
          minlength: 'Password must be at least 8 characters long.',
        }
      },
      submitHandler: function (form) {
        

        let actionUrl = base_url+"user/insert" ;
        
        //window.console.log($('#uform').serialize());
        $.ajax({
            type : 'POST',
            url : actionUrl,
            data : $('#uform').serialize(),
            success: function (data) {
                var result=data;
                
                if(result!=false)
                {
                    window.location.href=base_url;
                }
                else if(result =='Invalid Captcha'){
                  alert("Invalid Captcha");
                }
            
            }
        });
        
        return false;
        //form.submit();
      }
    });
  });